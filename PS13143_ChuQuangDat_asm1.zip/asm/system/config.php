<?php
    define("HOST_DB","localhost");
    define("NAME_DB", "phone");
    define("USER_DB", "root");
    define("PASS_DB","");
    define("ROOT_URL", "/asm");
    define("ADMIN_URL", ROOT_URL."/admin");
    define("SITE_URL", ROOT_URL."/site");
    define("SYSTEM_PATH", ROOT_URL."/system");

?>