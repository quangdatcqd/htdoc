<?php
    
    require_once "views/layout.php";
    class home{
        
    }
?>